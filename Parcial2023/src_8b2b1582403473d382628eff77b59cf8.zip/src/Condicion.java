
public abstract class Condicion {

	public abstract boolean cumple(Pieza3D pieza);
}
