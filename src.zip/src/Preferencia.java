
public abstract class Preferencia {
 public abstract boolean cumple(Pelicula P);
}
